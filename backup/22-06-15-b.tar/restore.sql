--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "XDaLvg2uUdnBWJYL";
--
-- Name: XDaLvg2uUdnBWJYL; Type: DATABASE; Schema: -; Owner: NmXuJXChwNgGEyNT
--

CREATE DATABASE "XDaLvg2uUdnBWJYL" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Russian_Russia.1252';


ALTER DATABASE "XDaLvg2uUdnBWJYL" OWNER TO "NmXuJXChwNgGEyNT";

\connect "XDaLvg2uUdnBWJYL"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ads; Type: TABLE; Schema: public; Owner: NmXuJXChwNgGEyNT
--

CREATE TABLE public.ads (
    id character varying,
    name character varying,
    content jsonb,
    tag character varying,
    phone character varying,
    create_date timestamp with time zone,
    active boolean,
    approved boolean
);


ALTER TABLE public.ads OWNER TO "NmXuJXChwNgGEyNT";

--
-- Name: codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.codes (
    id character varying,
    user_id character varying,
    code character varying,
    create_date timestamp with time zone,
    confirmed boolean
);


ALTER TABLE public.codes OWNER TO postgres;

--
-- Name: forum_comments; Type: TABLE; Schema: public; Owner: NmXuJXChwNgGEyNT
--

CREATE TABLE public.forum_comments (
    id character varying,
    content character varying,
    create_date timestamp with time zone,
    upvote integer,
    downvote integer,
    user_id character varying,
    forum_post_id character varying,
    reply_com_id character varying,
    reply_user_id character varying,
    nest_lvl integer,
    upvote_users jsonb,
    downvote_users jsonb
);


ALTER TABLE public.forum_comments OWNER TO "NmXuJXChwNgGEyNT";

--
-- Name: forum_posts; Type: TABLE; Schema: public; Owner: NmXuJXChwNgGEyNT
--

CREATE TABLE public.forum_posts (
    id character varying,
    content jsonb,
    create_date character varying,
    raiting integer,
    user_id character varying,
    views integer,
    tag_id character varying,
    title character varying,
    upvote_users jsonb,
    downvote_users jsonb,
    poleznoe boolean
);


ALTER TABLE public.forum_posts OWNER TO "NmXuJXChwNgGEyNT";

--
-- Name: kursy; Type: TABLE; Schema: public; Owner: NmXuJXChwNgGEyNT
--

CREATE TABLE public.kursy (
    id character varying,
    name character varying,
    buy real,
    sell real,
    update_date timestamp with time zone,
    type character varying,
    active boolean
);


ALTER TABLE public.kursy OWNER TO "NmXuJXChwNgGEyNT";

--
-- Name: news_comments; Type: TABLE; Schema: public; Owner: NmXuJXChwNgGEyNT
--

CREATE TABLE public.news_comments (
    id character varying,
    content character varying,
    create_date timestamp with time zone,
    upvote integer,
    downvote integer,
    user_id character varying,
    news_post_id character varying,
    reply_com_id character varying,
    reply_user_id character varying,
    nest_lvl character varying,
    upvote_users jsonb,
    downvote_users jsonb
);


ALTER TABLE public.news_comments OWNER TO "NmXuJXChwNgGEyNT";

--
-- Name: news_posts; Type: TABLE; Schema: public; Owner: NmXuJXChwNgGEyNT
--

CREATE TABLE public.news_posts (
    id character varying,
    title character varying,
    content jsonb,
    create_date timestamp with time zone,
    views integer,
    user_id character varying,
    tag_id character varying,
    emote1 bigint,
    emote2 bigint,
    emote3 bigint,
    emote4 bigint,
    emote5 bigint
);


ALTER TABLE public.news_posts OWNER TO "NmXuJXChwNgGEyNT";

--
-- Name: notes; Type: TABLE; Schema: public; Owner: NmXuJXChwNgGEyNT
--

CREATE TABLE public.notes (
    id character varying,
    user_id character varying,
    type character varying,
    viewed boolean,
    count integer,
    action character varying,
    subject_id character varying,
    create_date timestamp with time zone,
    update_vote_users jsonb
);


ALTER TABLE public.notes OWNER TO "NmXuJXChwNgGEyNT";

--
-- Name: opros; Type: TABLE; Schema: public; Owner: NmXuJXChwNgGEyNT
--

CREATE TABLE public.opros (
    id character varying,
    title character varying,
    ans jsonb,
    ips jsonb,
    create_date timestamp with time zone
);


ALTER TABLE public.opros OWNER TO "NmXuJXChwNgGEyNT";

--
-- Name: palata_comments; Type: TABLE; Schema: public; Owner: NmXuJXChwNgGEyNT
--

CREATE TABLE public.palata_comments (
    id character varying,
    content character varying,
    create_date timestamp with time zone,
    upvote integer,
    downvote integer,
    user_id character varying,
    palata_post_id character varying,
    reply_com_id character varying,
    reply_user_id character varying,
    nest_lvl integer,
    upvote_users jsonb,
    downvote_users jsonb
);


ALTER TABLE public.palata_comments OWNER TO "NmXuJXChwNgGEyNT";

--
-- Name: palata_posts; Type: TABLE; Schema: public; Owner: NmXuJXChwNgGEyNT
--

CREATE TABLE public.palata_posts (
    id character varying,
    title character varying,
    content jsonb,
    upvote integer,
    downvote integer,
    create_date timestamp with time zone,
    views integer,
    user_id character varying,
    tag_id character varying,
    upvote_users jsonb,
    downvote_users jsonb
);


ALTER TABLE public.palata_posts OWNER TO "NmXuJXChwNgGEyNT";

--
-- Name: s_images; Type: TABLE; Schema: public; Owner: NmXuJXChwNgGEyNT
--

CREATE TABLE public.s_images (
    id character varying,
    create_date timestamp with time zone
);


ALTER TABLE public.s_images OWNER TO "NmXuJXChwNgGEyNT";

--
-- Name: tags; Type: TABLE; Schema: public; Owner: NmXuJXChwNgGEyNT
--

CREATE TABLE public.tags (
    id character varying(64),
    name character varying(32),
    type character varying(8),
    "desc" character varying,
    latin character varying
);


ALTER TABLE public.tags OWNER TO "NmXuJXChwNgGEyNT";

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying NOT NULL,
    email character varying,
    login character varying,
    pass character varying,
    role character varying,
    fake boolean,
    last_ip character varying,
    banned boolean,
    karma integer,
    reg_date timestamp with time zone,
    confirmed boolean,
    phone character varying,
    avatar character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: yaknet; Type: TABLE; Schema: public; Owner: NmXuJXChwNgGEyNT
--

CREATE TABLE public.yaknet (
    id character varying,
    name character varying,
    weight bigint,
    rate bigint,
    "desc" character varying,
    link character varying,
    active boolean,
    visits bigint,
    create_date timestamp with time zone,
    likes bigint
);


ALTER TABLE public.yaknet OWNER TO "NmXuJXChwNgGEyNT";

--
-- Data for Name: ads; Type: TABLE DATA; Schema: public; Owner: NmXuJXChwNgGEyNT
--

COPY public.ads (id, name, content, tag, phone, create_date, active, approved) FROM stdin;
\.
COPY public.ads (id, name, content, tag, phone, create_date, active, approved) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.codes (id, user_id, code, create_date, confirmed) FROM stdin;
\.
COPY public.codes (id, user_id, code, create_date, confirmed) FROM '$$PATH$$/3359.dat';

--
-- Data for Name: forum_comments; Type: TABLE DATA; Schema: public; Owner: NmXuJXChwNgGEyNT
--

COPY public.forum_comments (id, content, create_date, upvote, downvote, user_id, forum_post_id, reply_com_id, reply_user_id, nest_lvl, upvote_users, downvote_users) FROM stdin;
\.
COPY public.forum_comments (id, content, create_date, upvote, downvote, user_id, forum_post_id, reply_com_id, reply_user_id, nest_lvl, upvote_users, downvote_users) FROM '$$PATH$$/3360.dat';

--
-- Data for Name: forum_posts; Type: TABLE DATA; Schema: public; Owner: NmXuJXChwNgGEyNT
--

COPY public.forum_posts (id, content, create_date, raiting, user_id, views, tag_id, title, upvote_users, downvote_users, poleznoe) FROM stdin;
\.
COPY public.forum_posts (id, content, create_date, raiting, user_id, views, tag_id, title, upvote_users, downvote_users, poleznoe) FROM '$$PATH$$/3361.dat';

--
-- Data for Name: kursy; Type: TABLE DATA; Schema: public; Owner: NmXuJXChwNgGEyNT
--

COPY public.kursy (id, name, buy, sell, update_date, type, active) FROM stdin;
\.
COPY public.kursy (id, name, buy, sell, update_date, type, active) FROM '$$PATH$$/3362.dat';

--
-- Data for Name: news_comments; Type: TABLE DATA; Schema: public; Owner: NmXuJXChwNgGEyNT
--

COPY public.news_comments (id, content, create_date, upvote, downvote, user_id, news_post_id, reply_com_id, reply_user_id, nest_lvl, upvote_users, downvote_users) FROM stdin;
\.
COPY public.news_comments (id, content, create_date, upvote, downvote, user_id, news_post_id, reply_com_id, reply_user_id, nest_lvl, upvote_users, downvote_users) FROM '$$PATH$$/3363.dat';

--
-- Data for Name: news_posts; Type: TABLE DATA; Schema: public; Owner: NmXuJXChwNgGEyNT
--

COPY public.news_posts (id, title, content, create_date, views, user_id, tag_id, emote1, emote2, emote3, emote4, emote5) FROM stdin;
\.
COPY public.news_posts (id, title, content, create_date, views, user_id, tag_id, emote1, emote2, emote3, emote4, emote5) FROM '$$PATH$$/3364.dat';

--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: NmXuJXChwNgGEyNT
--

COPY public.notes (id, user_id, type, viewed, count, action, subject_id, create_date, update_vote_users) FROM stdin;
\.
COPY public.notes (id, user_id, type, viewed, count, action, subject_id, create_date, update_vote_users) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: opros; Type: TABLE DATA; Schema: public; Owner: NmXuJXChwNgGEyNT
--

COPY public.opros (id, title, ans, ips, create_date) FROM stdin;
\.
COPY public.opros (id, title, ans, ips, create_date) FROM '$$PATH$$/3372.dat';

--
-- Data for Name: palata_comments; Type: TABLE DATA; Schema: public; Owner: NmXuJXChwNgGEyNT
--

COPY public.palata_comments (id, content, create_date, upvote, downvote, user_id, palata_post_id, reply_com_id, reply_user_id, nest_lvl, upvote_users, downvote_users) FROM stdin;
\.
COPY public.palata_comments (id, content, create_date, upvote, downvote, user_id, palata_post_id, reply_com_id, reply_user_id, nest_lvl, upvote_users, downvote_users) FROM '$$PATH$$/3366.dat';

--
-- Data for Name: palata_posts; Type: TABLE DATA; Schema: public; Owner: NmXuJXChwNgGEyNT
--

COPY public.palata_posts (id, title, content, upvote, downvote, create_date, views, user_id, tag_id, upvote_users, downvote_users) FROM stdin;
\.
COPY public.palata_posts (id, title, content, upvote, downvote, create_date, views, user_id, tag_id, upvote_users, downvote_users) FROM '$$PATH$$/3367.dat';

--
-- Data for Name: s_images; Type: TABLE DATA; Schema: public; Owner: NmXuJXChwNgGEyNT
--

COPY public.s_images (id, create_date) FROM stdin;
\.
COPY public.s_images (id, create_date) FROM '$$PATH$$/3368.dat';

--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: NmXuJXChwNgGEyNT
--

COPY public.tags (id, name, type, "desc", latin) FROM stdin;
\.
COPY public.tags (id, name, type, "desc", latin) FROM '$$PATH$$/3369.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, login, pass, role, fake, last_ip, banned, karma, reg_date, confirmed, phone, avatar) FROM stdin;
\.
COPY public.users (id, email, login, pass, role, fake, last_ip, banned, karma, reg_date, confirmed, phone, avatar) FROM '$$PATH$$/3370.dat';

--
-- Data for Name: yaknet; Type: TABLE DATA; Schema: public; Owner: NmXuJXChwNgGEyNT
--

COPY public.yaknet (id, name, weight, rate, "desc", link, active, visits, create_date, likes) FROM stdin;
\.
COPY public.yaknet (id, name, weight, rate, "desc", link, active, visits, create_date, likes) FROM '$$PATH$$/3371.dat';

--
-- PostgreSQL database dump complete
--

